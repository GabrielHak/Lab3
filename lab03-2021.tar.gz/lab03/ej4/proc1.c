#include <stdio.h>

void absolute(int x, int y) {
    // Completar aqui
}

int main(void) {
    // Completar aqui
    return 0;
}

